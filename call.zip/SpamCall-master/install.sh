pkg update
pkg upgrade
apt-get install php -y
apt install git -y
php SpamCall.php


